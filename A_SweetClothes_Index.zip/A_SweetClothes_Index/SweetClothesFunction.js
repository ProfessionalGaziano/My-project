function Scroll{
  window.addEventListener("scroll",function()){
    var header =document.querySelector("header");
    header.classList.toggle("sticky",window.scollY>0);
  }
}
